Below is an description for each file/folder in the zip
1.  scraper.ipynb : The scrapping process to get the data from TripAdvisor
2.  scraped_data.csv : The scraped data
3.  pass.txt : Contains the password to connect to the online Mongo database created for the purpose of this project
4.  dataFields.py : A python script that contains all the MongoDB field names as a constant for ease of use
5.  sentiment_analysis.ipynb : The sentiment analysis process
6.  basic_visualization.ipynb : The basic visualization process
7.  united_states.csv : A list of the united states used with basic visualization
8.  countries.csv : A list of countries used with basic visualization
9.  words.csv : A table with the individual words used from all the reviews and their frequency usage throughout the years. Used with basic visualization.
10. final_map.html : The map visualization process og the reviewers' location
11. User_Profiling.ipynb : The user profiling process
12. Web Scraping Tutorial.pdf : The actual tutorial
13. plots : The plots produced by the processes